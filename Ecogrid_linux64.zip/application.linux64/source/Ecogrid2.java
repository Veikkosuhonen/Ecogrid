import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Ecogrid2 extends PApplet {


int s = 1440;
int cellsize = 4;
int gs = s/cellsize;

float mRate  = 0.03f;

float[] foodMap = new float[(gs) * (gs)];
int[] cMap = new int[(gs) * (gs)];

FloatList births;
FloatList deaths;
FloatList population;

boolean pause = false;

ArrayList<Creature> creaturesA = new ArrayList();
ArrayList<Creature> creaturesN = new ArrayList();
ArrayList<Creature> creaturesR = new ArrayList();
Cell[] cells = new Cell[gs*gs];

public void setup() {
  
  background(255);
  
  colorMode(HSB);
  //frameRate(3);
  
  foodMap = noisemap(foodMap,0.02f,1);
  cMap = colorMap(foodMap,0,255);
  foodMap = limitIt(foodMap);
  
  births = new FloatList();
  deaths = new FloatList();
  population = new FloatList();
  
  for (int i = 0; i < gs*gs;i++) {
    cells[i] = new Cell(getCord(i),foodMap[i],cMap[i]);
  }

  for (int i = 0;i<2000;i++) {
    creaturesA.add(new Creature());
  }
}


public void draw() {

  for (Cell c:cells) {
    c.grow();
    c.display();
  }

  for (Creature c:creaturesA) {
    if (c.alive) {
      if (true) {
        c.reproduce();
        c.selectTarget(1);
        c.move();
        c.attack();
        c.eat();
        c.starve(false);
        
      }
      c.display();
    }
  }
  births = updateStatList(births,countBirths(),400);
  deaths = updateStatList(deaths,countDeaths(),400);
  population = updateStatList(population,countAlive(),400);
  
  creaturesA.removeAll(creaturesR);
  creaturesA.addAll(creaturesN);
  creaturesR.clear();
  creaturesN.clear();
}

public float[] noisemap(float[] map, float i,float mult) {
  noiseDetail(12);
  for (int y = 0; y<gs; y++) {
    for (int x = 0; x<gs; x++) {
      map[x+y*gs] = noise(i*x,i*y)*mult;
    }  
  }
  return map;
}


public int[] colorMap(float[] map,float min,float max) {
  int[] cmap = new int[gs*gs];
  for (int y = 0; y<gs; y++) {
    for (int x = 0; x<gs; x++) {
      if (map[x+y*gs]>1) {
        cmap[x+y*gs] = 0;
      } else if (map[x+y*gs]>1) {
        cmap[x+y*gs] = 1;
      } else {cmap[x+y*gs] = 2;}
    }
  }
  return cmap;
}


public float[] getCord(int i) {
  float[] pos = new float[2];
  pos[0] = i % gs;
  pos[1] = ceil(i/gs);
  return pos;
}


public int getIndex(float[] pos) {
  int i = min(floor(gs*pos[1]+pos[0]),gs*gs-1);
  i = max(i,0);
  return i;
}


public float[] limitIt(float[] map) {
  for (int y = 0; y<gs; y++) {
    for (int x = 0; x<gs; x++) {
      if (map[x+y*gs] < 0.35f) {map[x+y*gs]=0;} else if (map[x+y*gs] > 1) {map[x+y*gs]=0;}
      else {map[x+y*gs]=min(map[x+y*gs]*2-0.6f,1);}
    }
  }
  return map;
}

public void printArray(float[] a) {
  print("[");
  for (int i = 0;i<a.length; i++) {
    print(a[i]+", ");
  }
  print("]\n");
}
public int countAlive() {
  return creaturesA.size();
}
public int countDeaths() {
  return creaturesR.size();
}
public int countBirths() {
  return creaturesN.size();
}
public FloatList updateStatList(FloatList list,float value, int length) {
  list.append(value);
  if (list.size()>length) {
    list.remove(0);
  }
  return list;
}

public void mousePressed() {
  if (pause) {pause = false; loop();} else {pause = true; noLoop();
    rectMode(CORNERS);
    fill(255);
    rect(130,50,1200,1200);
    
    float[] avgs = getAverages();
    String info = " foodW: "+avgs[0]+
    "\n biggerCreatureW: "+avgs[1]+
    "\n smallerCreatureW: "+avgs[2]+
    "\n birthlimit: "+avgs[3]+
    "\n eatRate: "+avgs[4]+
    "\n eatEff: "+avgs[5]+
    "\n moveEff: "+avgs[6]+
    "\n powerLevel: "+avgs[7]+
    "\n count: "+avgs[8];
    fill(0);
    textSize(15);
    text(info, 140, 100);
    
    FloatList nutritions = new FloatList();
    FloatList birthlimits = new FloatList();
    FloatList eatRates = new FloatList();
    FloatList eatEffs = new FloatList();
    FloatList moveEffs = new FloatList();
    FloatList powerLevels = new FloatList();
    FloatList foodWeigths = new FloatList();
    FloatList bcWeigths = new FloatList();
    FloatList scWeigths = new FloatList();
    
    
    for (Creature c:creaturesA) {
      nutritions.append(c.nutrition);
      birthlimits.append(c.birthLimit);
      eatRates.append(c.eatRate);
      eatEffs.append(c.eatEff);
      moveEffs.append(c.moveEff);
      powerLevels.append(c.powerLevel);
      foodWeigths.append(c.foodW);
      bcWeigths.append(c.biggerCreatureW);
      scWeigths.append(c.smallerCreatureW);
    }
    ArrayList<Graph> graphs = new ArrayList();
    graphs.add(new Graph(140,400,300,100,nutritions,40));
    graphs.add(new Graph(140,520,300,100,birthlimits,40));
    graphs.add(new Graph(140,640,300,100,eatRates,40));
    graphs.add(new Graph(140,760,300,100,eatEffs,40));
    graphs.add(new Graph(140,880,300,100,moveEffs,40));
    
    graphs.add(new Graph(455,400,300,100,powerLevels,40));
    graphs.add(new Graph(455,520,300,100,foodWeigths,40));
    graphs.add(new Graph(455,640,300,100,bcWeigths,40));
    graphs.add(new Graph(455,760,300,100,scWeigths,40));
    for(Graph g:graphs) {
      g.generate();
      g.display();
    }
    ArrayList<Linegraph> linegraphs = new ArrayList();
    linegraphs.add(new Linegraph(750,100,400,200,population));
    linegraphs.add(new Linegraph(750,300,400,200,births));
    linegraphs.add(new Linegraph(750,500,400,200,deaths));
    for (Linegraph g:linegraphs) {
      g.generate();
      g.display();
    }
    rectMode(0);
  }
}
public float[] getAverages() {
  int n = 0;
  float[] averages = new float[9];
  float foodW=0;
  float biggerCreatureW=0;
  float smallerCreatureW=0;
 
  float birthLimit=0;
  float eatRate=0;
  float eatEff=0;
  float moveEff=0;
  float powerLevel=0;
  for (Creature c: creaturesA) {if (c.alive) {n++;
    foodW += c.foodW;
    biggerCreatureW+=c.biggerCreatureW;
    smallerCreatureW+=c.smallerCreatureW;
    birthLimit+=c.birthLimit;
    eatRate+=c.eatRate;
    eatEff+=c.eatEff;
    moveEff+=c.moveEff;
    powerLevel+=c.powerLevel;
  }}
  averages[0] = foodW/n;
  averages[1] = biggerCreatureW/n;
  averages[2] = smallerCreatureW/n;
  averages[3] = birthLimit/n;
  averages[4] = eatRate/n;
  averages[5] = eatEff/n;
  averages[6] = moveEff/n;
  averages[7] = powerLevel/n;
  averages[8] = n;
  return averages;
}
/*class Carnivore {
  float col;
  float shape;
  
  float foodW;
  float creatureW;
  float birthLimit;
  
  float nutrition;
  float startNutrition;
  boolean alive;
  
  float[] pos = new float[2];
  float[] tpos = new float[2];
  float[] npos = new float[2];
  
  Carnivore() {
    pos[0] = random(gs); pos[1] = random(gs);
    tpos[0] = pos[0]; tpos[1] = pos[1];
    col = random(255);
    shape = random(0.1,0.9);
    alive = true;
    nutrition = random(10,30);
    startNutrition = nutrition;
    foodW = random(-1,1);
    creatureW = random(-1,1);
    birthLimit = random(10,20);
    
    cells[getIndex(pos)].hasCarnivore++;
    
  }
  
  void selectTarget(int i) {
    float maxWeight = evaluateWeight(pos);
    float localWeight;
    
    npos[0] = max(pos[0]-i,0);
    npos[1] = max(pos[1]-i,0);
    
    tpos[0] = max(npos[0],0);
    tpos[1] = max(npos[1],0);
    
    for (int j = 0; j<2*i; j++) {
      //printArray(npos);
      localWeight = evaluateWeight(npos);
      //println(localWeight);
      if (localWeight>maxWeight) {maxWeight = localWeight;
        tpos[0] = min(npos[0],gs);
        tpos[1] = npos[1];
        //println("bling1: "+tpos);
      }
      
      npos[0] = min(npos[0]+1,gs);
    }
    for (int j = 0; j<2*i; j++) {
      //printArray(npos);
      localWeight = evaluateWeight(npos);
      //println(localWeight);
      if (localWeight>maxWeight) {maxWeight = localWeight;
        tpos[0] = npos[0];
        tpos[1] = min(npos[1],gs);
        //println("bling2: "+tpos);
      }
      
      npos[1] = min(npos[1]+1,gs);
      
    }
    for (int j = 0; j<2*i; j++) {
      //printArray(npos);
      localWeight = evaluateWeight(npos);
      //println(localWeight);
      if (localWeight>maxWeight) {maxWeight = localWeight;
        tpos[0] = max(npos[0],0);
        tpos[1] = npos[1];
        //println("bling3: "+tpos);
      }
      
      npos[0] = max(npos[0]-1,0);
      
    }
    for (int j = 0; j<2*i; j++) {
      //printArray(npos);
      localWeight = evaluateWeight(npos);
      //println(localWeight);
      if (localWeight>maxWeight) {maxWeight = localWeight;
        tpos[0] = npos[0];
        tpos[1] = max(npos[1],0);
        //println("bling4: "+tpos);
      }
      
      npos[1] = max(npos[1]-1,0);;
      nutrition -= 0.01;
    }
    /*println("max: "+maxWeight);
    println("pos: "+evaluateWeight(pos) + " "+pos);
    
    print("target: "); printArray(tpos);
    println("target niceness: "+evaluateWeight(tpos));
    
    
    if (maxWeight == evaluateWeight(pos)) {tpos[0]=pos[0];tpos[1]=pos[1];nutrition-=0.1;}
  }
  float evaluateWeight(float[] npos) {
    float weigth = 0;
    
    weigth += cells[getIndex(npos)].food * foodW;
    if (cells[getIndex(pos)].hasCreature>0) {
      weigth += creatureW;
    }
    if (cells[getIndex(pos)].hasCarnivore>0) {
      weigth -= 100;
    }
    return weigth;
  }
   void move() {
    cells[getIndex(pos)].hasCarnivore--;
    
    pos[0] = tpos[0];
    pos[1] = tpos[1];
    
    if (pos[0]>gs) {pos[0]=gs;}
    else if (pos[0]<0) {pos[0]=0;}
    if (pos[1]>gs) {pos[1]=gs;}
    else if (pos[1]<0) {pos[1]=0;}
    cells[getIndex(pos)].hasCarnivore++;
    nutrition -= 0.2;
  }
  void eat() {
    if (cells[getIndex(pos)].localCreature != null) {
      nutrition += cells[getIndex(pos)].localCreature.nutrition;
      cells[getIndex(pos)].localCreature.starve(true);
    }
  }
  void starve(boolean now) {
    if (nutrition<=0 || now) {
      
      alive = false;
      cells[getIndex(pos)].hasCarnivore--;
      deathRate++;
    }
  }
  
  void reproduce() {
    if (nutrition>birthLimit) {
      for (Carnivore c: carnivores) {
        if (c.alive != true) {
          c = new Creature(
          round(min(pos[0]+random(1),gs)),
          round(min(pos[1]+random(1),gs)),
          foodW + random(-1,1)*mRate,
          constrain(shape + random(-1,1)*mRate, 0.1,0.9),
          col + random(-1,1)*mRate*50,
          constrain(birthLimit + random(-1,1)*mRate*10,1,100),
          nutrition/3
          );
          
          c.alive = true;
          c.pos[0] = round(min(pos[0]+random(1),gs));
          c.pos[1] = round(min(pos[1]+random(1),gs));
          c.foodW = foodW + random(-1,1)*mRate;
          c.creatureW = creatureW + random(-1,1)*mRate;
          
          c.shape = constrain(shape + random(-1,1)*mRate, 0.1,0.9);
          c.col = col + random(-1,1)*mRate*200;
          c.birthLimit = max(birthLimit + random(-1,1)*mRate*10,2);
          c.nutrition = nutrition/3;
          
          birthRate++;
          cells[getIndex(pos)].hasCarnivore++;
          nutrition -= max(nutrition/2,0);
          break;
        }
      }
      
    }
  }
  void display() {
    
    fill(col,255,255);
    
    ellipse(
      pos[0]*cellsize+cellsize/2,
      pos[1]*cellsize+cellsize/2,
      
      min(1.7*cellsize*(1-shape)*2,  cellsize*1.7),
      min(1.7*cellsize*shape*2,  cellsize*1.7)
    );
  }
}*/
class Cell {
  float food;
  int terrain;
  float[] pos = new float[2];
  float max;
  
  ArrayList<Creature> creatures;
  
  Cell(float[] p,float foodLevel,int terrainLevel) {
    pos = p;
    pos[0] *= cellsize;
    pos[1] *= cellsize;
    food = foodLevel;
    max = foodLevel;
    terrain = terrainLevel;
    creatures = new ArrayList();
  }
  
  
  public void display() {
    noStroke();
    if (terrain == 0) {fill(180,190,200);}
    else if (terrain == 1) {fill(150,190,240);}
    else {fill(100,255,food*255);}
    rect(pos[0],pos[1],cellsize,cellsize);
  }
  
  public void grow() {
    if (food<max) {
      food += 0.006f;
      
    }

  }
}
class Creature {
  
  float col;
  float shape;
  
  float foodW;
  float biggerCreatureW;
  float smallerCreatureW;
  
  float birthLimit;
  
  float eatRate0;
  float eatEff0;
  float moveEff0;
  float powerLevel0;
  
  float eatRate;
  float eatEff;
  float moveEff;
  float powerLevel;
  
  float nutrition;
  float startNutrition;
  boolean alive;
  boolean reproducing;
  
  float[] pos = new float[2];
  float[] tpos = new float[2];
  float[] npos = new float[2];
  
  Creature() {
      pos[0] = random(gs); pos[1] = random(gs);
      tpos[0] = pos[0]; tpos[1] = pos[1];
      col = random(255);
      shape = random(-1,1);
      alive = true;
      
      
      foodW = random(0,1);
      biggerCreatureW = random(-1,1);
      smallerCreatureW = random(-1,1);
      
      birthLimit = random(5,30);
      nutrition = random(5,15);
      startNutrition = 1;
      reproducing = false;
      
      eatRate0 = random(1);;
      eatEff0 = random(1);
      moveEff0 = random(1);
      powerLevel0 = random(1);
      float sum = eatRate0+eatEff0+moveEff0+powerLevel0;
      
      eatRate = eatRate0/sum;
      eatEff = eatEff0/sum;
      moveEff = moveEff0/sum;
      powerLevel = powerLevel0/sum;
      
      cells[getIndex(pos)].creatures.add(this);
  }
  Creature(int x, int y, float c, float s, float f, float bcw, float scw, float bl, float n, float sn, float er, float ef, float me, float pl) {
      pos[0] = x; pos[1] = y;
      tpos[0] = x; tpos[1] = y;
      col = c;
      shape = s;
      alive = true;
      
      
      foodW = f;
      biggerCreatureW = bcw;
      smallerCreatureW = scw;
      
      birthLimit = bl;
      nutrition = n;
      startNutrition = 1;
      reproducing = false;
      
      eatRate0 = er;
      eatEff0 = ef;
      moveEff0 = me;
      powerLevel0 = pl;
      float sum = eatRate0+eatEff0+moveEff0+powerLevel0;
    
      eatRate = max(eatRate0/sum,0.06f);
      eatEff = max(eatEff0/sum,0.06f);
      moveEff = moveEff0/sum;
      powerLevel = powerLevel0/sum;
      
      cells[getIndex(pos)].creatures.add(this);
  }
  
  public void selectTarget(int i) {
    if (!reproducing) {
      
    float maxWeight = evaluateWeight(pos);
    float localWeight;
    
    npos[0] = max(pos[0]-i,0);
    npos[1] = max(pos[1]-i,0);
    
    tpos[0] = max(npos[0],0);
    tpos[1] = max(npos[1],0);
    
    for (int j = 0; j<2*i; j++) {
      //printArray(npos);
      localWeight = evaluateWeight(npos);
      //println(localWeight);
      if (localWeight>maxWeight) {maxWeight = localWeight;
        tpos[0] = min(npos[0],gs);
        tpos[1] = npos[1];
        //println("bling1: "+tpos);
      }
      
      npos[0] = min(npos[0]+1,gs);
    }
    for (int j = 0; j<2*i; j++) {
      //printArray(npos);
      localWeight = evaluateWeight(npos);
      //println(localWeight);
      if (localWeight>maxWeight) {maxWeight = localWeight;
        tpos[0] = npos[0];
        tpos[1] = min(npos[1],gs);
        //println("bling2: "+tpos);
      }
      
      npos[1] = min(npos[1]+1,gs);
      
    }
    for (int j = 0; j<2*i; j++) {
      //printArray(npos);
      localWeight = evaluateWeight(npos);
      //println(localWeight);
      if (localWeight>maxWeight) {maxWeight = localWeight;
        tpos[0] = max(npos[0],0);
        tpos[1] = npos[1];
        //println("bling3: "+tpos);
      }
      
      npos[0] = max(npos[0]-1,0);
      
    }
    for (int j = 0; j<2*i; j++) {
      //printArray(npos);
      localWeight = evaluateWeight(npos);
      //println(localWeight);
      if (localWeight>maxWeight) {maxWeight = localWeight;
        tpos[0] = npos[0];
        tpos[1] = max(npos[1],0);
        //println("bling4: "+tpos);
      }
      
      npos[1] = max(npos[1]-1,0);;
      
    }
    /*println("max: "+maxWeight);
    println("pos: "+evaluateWeight(pos) + " "+pos);
    
    print("target: "); printArray(tpos);
    println("target niceness: "+evaluateWeight(tpos));*/
    
    
    }
  }
  
  
  public float evaluateWeight(float[] npos) {
    float weigth = 0;
    float creatureWeight = 0;
    weigth += cells[getIndex(npos)].food * foodW;
    
    if (!cells[getIndex(npos)].creatures.isEmpty()) {
      for (Creature c : cells[getIndex(npos)].creatures) {
        if (c.nutrition>nutrition) {
          creatureWeight += biggerCreatureW;
        } else if (c.nutrition<nutrition) {
          creatureWeight += smallerCreatureW;
        }
      }
      weigth += creatureWeight/cells[getIndex(npos)].creatures.size();
    }
    
    return weigth;
  }
  
  
  public void move() {
    
      
    cells[getIndex(pos)].creatures.remove(this);
    
    pos[0] = tpos[0];
    pos[1] = tpos[1];
    
    if (pos[0]>gs) {pos[0]=gs;}
    else if (pos[0]<0) {pos[0]=0;}
    if (pos[1]>gs) {pos[1]=gs;}
    else if (pos[1]<0) {pos[1]=0;}
    
    cells[getIndex(pos)].creatures.add(this);
    
    nutrition -= 1/(moveEff*6)+0.04f;
    
    
  }
  
  public void eat() {
    
      
    if (cells[getIndex(pos)].food>0.3f) {
      float newfood = (eatRate*0.15f)*cells[getIndex(pos)].food;
      cells[getIndex(pos)].food = max(cells[getIndex(pos)].food-newfood-0.05f,0);
      
      nutrition += newfood*eatEff*70;
    }
    
  }
  public void attack() {
    
      
    Creature target = null;
    float maxNutrition = 0;
    for(Creature c:cells[getIndex(pos)].creatures) {
      if (c.getStrength()<getStrength()) {
        if (c.nutrition>maxNutrition) {
          maxNutrition=c.nutrition;
          target = c;
        }
      }
    }
    if (target!=null) {
      target.starve(false);
      nutrition+=target.nutrition*1;
    }
  
  }
  
  public void starve(boolean now) {
    if (nutrition<=0 || now) {
      cells[getIndex(pos)].creatures.remove(this);
      alive = false;
      creaturesR.add(this);
      //cells[getIndex(pos)].food += 0.1;
      
    }
  }
  
  public void reproduce() {
    if (nutrition>birthLimit) {
      
      /*for (Creature c: creatures) {
        if (c.alive != true) {
          /*c = new Creature(
          round(min(pos[0]+random(1),gs)),
          round(min(pos[1]+random(1),gs)),
          foodW + random(-1,1)*mRate,
          constrain(shape + random(-1,1)*mRate, 0.1,0.9),
          col + random(-1,1)*mRate*50,
          constrain(birthLimit + random(-1,1)*mRate*10,1,100),
          nutrition/3
          );
          if (random(200)>199) {mRate *= 20;}
          c.alive = true;
          c.pos[0] = round(min(pos[0]+random(1),gs));
          c.pos[1] = round(min(pos[1]+random(1),gs));
          c.foodW = foodW + random(-1,1)*mRate;
          c.biggerCreatureW = biggerCreatureW + random(-1,1)*mRate;
          c.smallerCreatureW = smallerCreatureW + random(-1,1)*mRate;
          c.eatRate = eatRate + random(-1,1)*mRate;
          c.shape = constrain(shape + random(-1,1)*mRate, 0.1,0.9);
          c.col = col + random(-1,1)*mRate*200;
          c.birthLimit = constrain(birthLimit + random(-1,1)*mRate*10,1,100);
          c.eatEff = (1+random(-1,1)*mRate)-eatRate+0.1;
          c.moveEff = max(moveEff + random(-1,1)*mRate*0.1,0);
          c.nutrition = nutrition/3;
          cells[getIndex(c.pos)].creatures.add(c);
          birthRate++;
          nutrition -= nutrition/2;
          mRate = 0.01;
          break;
          
          
        }
      } */
      creaturesN.add(new Creature(
        round(constrain(pos[0]+random(1)*6-3,0,gs)),
        round(constrain(pos[1]+random(1)*6-3,0,gs)),
        col + random(-1,1)*mRate*200,
        constrain(shape + random(-1,1)*mRate, 0.1f,0.9f),
        constrain(foodW + random(-1,1)*mRate,0,1),
        biggerCreatureW + random(-1,1)*mRate,
        smallerCreatureW + random(-1,1)*mRate,
        constrain(birthLimit + random(-1,1)*mRate*10,1,100),
        nutrition/4,
        1,
        constrain(eatRate0 + random(-1,1)*mRate,0,1),
        constrain(eatEff0 + random(-1,1)*mRate,0,1),
        constrain(moveEff0 + random(-1,1)*mRate*0.1f,0,1),
        constrain(powerLevel0 +random(-1,1)*mRate,0,1)
      ));
      this.nutrition *= 3/4;

    }
  }
  
  public void display() {
    
    float m = sqrt(nutrition);
    
    fill(col,255-155*powerLevel,255);
    
    ellipse(
      pos[0]*cellsize+cellsize/2,
      pos[1]*cellsize+cellsize/2,
      
      min(cellsize*(1-shape)*2*m,  cellsize*m),
      min(cellsize*shape*2*m,  cellsize*m)
    );
  }
  public float getStrength() {
    return nutrition*(1+powerLevel*8);
  }
  
}
class Graph {
  private FloatList values;
  private int x,y,w,h,steps;
  private float offset,maxV;
  private float Xaxis;
  private int[] histogram;
  private int max;
  Graph(int x,int y,int w, int h,FloatList values, int steps) {
    this.values = values;
    this.steps = steps;
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    histogram = new int[steps];
    max = 0;
  }
  public void generate() {
    maxV = values.max();
    
    float minV = values.min();
    float span = maxV-minV;
    offset = 0;
    if (minV<0) {offset-=minV;maxV+=offset;max+=offset;}
    for (float f:values) {
      f+=offset;
      
      histogram[round(f/maxV*(steps-1))]++;
    }
    Xaxis = round(offset/maxV*(steps-1))*(w/steps);
    
    for (int i = 0;i<histogram.length;i++) {
      if (histogram[i]>max) max = histogram[i];
    }
  }
  public void display() {
    
    stroke(0);
    rectMode(CORNERS);
    line(x+Xaxis,y-5,x+Xaxis,y+h+5);
    line(x,y+h,x+w,y+h);
    fill(200);
    
    for (int i = 0;i<steps;i++) {
      rect(
        x+(w/steps)*i,
        y+h,
        x+(w/steps)*i+w/steps,
        y+h-(histogram[i]*1.0f)/max*h
      );
      
    }
    
    strokeWeight(2);
    line(x+Xaxis,y-5,x+Xaxis,y+h+5);
    line(x,y+h,x+w,y+h);
    fill(200);
    
    strokeWeight(1);
    rectMode(0);
    noStroke();
  }
}
class Linegraph {
  private FloatList values;
  private int x,y,w,h,steps, off;
  private int max;
  Linegraph(int x,int y,int w, int h,FloatList values) {
    this.values = values;
    this.steps = values.size();
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    
    max = 0;
  }
  public void generate() {
    float maxV = values.max();
    
    float minV = values.min();
    float span = maxV-minV;
    
    FloatList newList = new FloatList();
    for (float f:values) {
      f-=minV;
      newList.append(f/span*h);
    }
    values = newList;
  }
  public void display() {
    
    
    fill(128,255,125);
    
    
    for (int i = 0;i<steps;i++) {
      ellipse(
        x + (w*1.0f/steps)*i,
        y + h - values.get(i),
        2,2
      );
      
    }
    stroke(0);
    line(x,y,x,y+h);
    line(x,y+h,x+w,y+h);
    noStroke();
    
    
    
  }
}
  public void settings() {  size(1440,1440); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Ecogrid2" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
